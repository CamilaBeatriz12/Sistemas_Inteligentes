# ----------------------------------------------------------
# ----------------------------------------------------------

knnDiscreto <- function(training, query, k) {
  
  features = training[ , -ncol(training)]
  target   = training[ , ncol(training)]
  
  # 1. calcular a distancia de query p todos as instancias
  # do treino
  distances = c()
  
  for(i in 1:nrow(features)) {
    distances[i] = sqrt(sum((features[i,] - query[-5])^2))
  }
  
  # 2. ordenar as distancias, e encontrar as K menores
  k.ids = order(distances)
  
  # 3. pegar a moda/maior numero de votos dos K mais proximos
  target.freq = target[k.ids[1:k]]
  
  # retorna o id da classe predita
  idClass = names(which.max(table(target.freq)))
  return(idClass)
}

# ----------------------------------------------------------
# ----------------------------------------------------------

# ----------------------------------------------------------
# ----------------------------------------------------------

data = dataset_1464_blood

#Para treino eu separei 500 e para teste 248
treino = data[ c(1:166, 250:417, 500:667),]
teste  = data[-c(1:166, 250:417, 500:667),]

# prever a classe dos elementos do conjunto de teste
preds = c()

aux = lapply(c(1, 3, 5, 7, 9, 13), function(k) {
  cat("Para K = ", k, "\n")
  for(i in 1:nrow(teste)) {
    query = teste[i, ]
    preds[i] = knnDiscreto(training = treino, query = query, k = k)
  }
  conf.mat = table(as.factor(teste$V1), as.factor(preds))
  acc = sum(diag(conf.mat))/sum(conf.mat)
  print(acc)
  return(acc)
})

# preds - predicoes feitas pelo KNN p conjunto de teste
# 7 0.0.9666667

# ----------------------------------------------------------
# ----------------------------------------------------------